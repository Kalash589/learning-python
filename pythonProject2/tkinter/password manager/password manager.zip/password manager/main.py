from tkinter import *
FONT_NAME = "Aerial"
# ---------------------------- PASSWORD GENERATOR ------------------------------- #


# ---------------------------- SAVE PASSWORD ------------------------------- #
def save():
    website=website_entry.get()
    username=Username_entry.get()
    password=Password_entry.get()

    with open("data.txt" ,"a") as data_file:
        data_file.write(f"{website} | {username} | {password}\n")
        website_entry.delete(0,END)
        password_entry.delete(0,END)





# ---------------------------- UI SETUP ------------------------------- #

window=Tk()
window.title("Password Generator")
window.minsize(600,400)
window.config(padx=50,pady=50,bg="white")

canvas=Canvas(width=200, height=190 , highlightthickness=0, bg="white")
logo_pic=PhotoImage(file="logo.png")
canvas.create_image(100,100 ,image=logo_pic)
canvas.grid(column=1 , row = 0)

website_label=Label(text="Website:" ,font=(FONT_NAME,20) , bg="white" , fg="black")
website_label.grid(column=0 , row=1)

username_label=Label(text="Username/Email:" ,font=(FONT_NAME,20) , bg="white" , fg="black")
username_label.grid(column=0 , row=2)

Password_label=Label(text="Password:" ,font=(FONT_NAME,20) , bg="white" , fg="black")
Password_label.grid(column=0 , row=3)

website_entry=Entry(width=36,bg="white", fg="black" ,bd=1, highlightthickness=0,)
website_entry.grid(column=1,row=1 , columnspan=2)
website_entry.focus()


Username_entry=Entry(width=36,bg="white", highlightthickness=0,fg="black")
Username_entry.insert(0,"kalash@gmail.com")
Username_entry.grid(column=1,row=2 , columnspan=2)

Password_entry=Entry(width=21,bg="white", highlightthickness=0,fg="black")
Password_entry.grid(column=1,row=3 )

generate_button=Button(text="Generate Password")
generate_button.grid(column=2 , row =3)

Add_button=Button(text="Add", width=36 , highlightthickness=0 ,command=save)
Add_button.grid(column=1 , row =4,columnspan=2)





window.mainloop()